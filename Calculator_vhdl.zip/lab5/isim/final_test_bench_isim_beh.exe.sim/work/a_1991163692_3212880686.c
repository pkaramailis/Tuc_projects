/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/konos12/Desktop/proxwrimeni/LAB4/as_ovf.vhd";



static void work_a_1991163692_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;
    int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned char t28;
    unsigned char t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t8 = (0 - 2);
    t9 = (t8 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = *((unsigned char *)t1);
    t6 = (t5 == (unsigned char)2);
    if (t6 == 1)
        goto LAB28;

LAB29:    t4 = (unsigned char)0;

LAB30:    if (t4 == 1)
        goto LAB25;

LAB26:    t3 = (unsigned char)0;

LAB27:    if (t3 != 0)
        goto LAB22;

LAB24:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t8 = (0 - 2);
    t9 = (t8 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = *((unsigned char *)t1);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB36;

LAB37:    t4 = (unsigned char)0;

LAB38:    if (t4 == 1)
        goto LAB33;

LAB34:    t3 = (unsigned char)0;

LAB35:    if (t3 != 0)
        goto LAB31;

LAB32:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 2912);
    t2 = (t1 + 56U);
    t7 = *((char **)t2);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB23:
LAB3:    t1 = (t0 + 2832);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 1192U);
    t7 = *((char **)t1);
    t8 = (0 - 2);
    t9 = (t8 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t7 + t11);
    t12 = *((unsigned char *)t1);
    t13 = (t12 == (unsigned char)2);
    if (t13 == 1)
        goto LAB11;

LAB12:    t6 = (unsigned char)0;

LAB13:    if (t6 == 1)
        goto LAB8;

LAB9:    t5 = (unsigned char)0;

LAB10:    if (t5 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t8 = (0 - 2);
    t9 = (t8 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t5 = *((unsigned char *)t1);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB19;

LAB20:    t4 = (unsigned char)0;

LAB21:    if (t4 == 1)
        goto LAB16;

LAB17:    t3 = (unsigned char)0;

LAB18:    if (t3 != 0)
        goto LAB14;

LAB15:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 2912);
    t2 = (t1 + 56U);
    t7 = *((char **)t2);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(45, ng0);
    t30 = (t0 + 2912);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    *((unsigned char *)t34) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t30);
    goto LAB6;

LAB8:    t22 = (t0 + 1192U);
    t23 = *((char **)t22);
    t24 = (2 - 2);
    t25 = (t24 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t22 = (t23 + t27);
    t28 = *((unsigned char *)t22);
    t29 = (t28 == (unsigned char)3);
    t5 = t29;
    goto LAB10;

LAB11:    t14 = (t0 + 1192U);
    t15 = *((char **)t14);
    t16 = (1 - 2);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t14 = (t15 + t19);
    t20 = *((unsigned char *)t14);
    t21 = (t20 == (unsigned char)2);
    t6 = t21;
    goto LAB13;

LAB14:    xsi_set_current_line(46, ng0);
    t23 = (t0 + 2912);
    t30 = (t23 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t23);
    goto LAB6;

LAB16:    t15 = (t0 + 1192U);
    t22 = *((char **)t15);
    t24 = (2 - 2);
    t25 = (t24 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t15 = (t22 + t27);
    t20 = *((unsigned char *)t15);
    t21 = (t20 == (unsigned char)2);
    t3 = t21;
    goto LAB18;

LAB19:    t7 = (t0 + 1192U);
    t14 = *((char **)t7);
    t16 = (1 - 2);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t7 = (t14 + t19);
    t12 = *((unsigned char *)t7);
    t13 = (t12 == (unsigned char)3);
    t4 = t13;
    goto LAB21;

LAB22:    xsi_set_current_line(50, ng0);
    t23 = (t0 + 2912);
    t30 = (t23 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t23);
    goto LAB23;

LAB25:    t15 = (t0 + 1192U);
    t22 = *((char **)t15);
    t24 = (2 - 2);
    t25 = (t24 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t15 = (t22 + t27);
    t20 = *((unsigned char *)t15);
    t21 = (t20 == (unsigned char)2);
    t3 = t21;
    goto LAB27;

LAB28:    t7 = (t0 + 1192U);
    t14 = *((char **)t7);
    t16 = (1 - 2);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t7 = (t14 + t19);
    t12 = *((unsigned char *)t7);
    t13 = (t12 == (unsigned char)3);
    t4 = t13;
    goto LAB30;

LAB31:    xsi_set_current_line(51, ng0);
    t23 = (t0 + 2912);
    t30 = (t23 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t23);
    goto LAB23;

LAB33:    t15 = (t0 + 1192U);
    t22 = *((char **)t15);
    t24 = (2 - 2);
    t25 = (t24 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t15 = (t22 + t27);
    t20 = *((unsigned char *)t15);
    t21 = (t20 == (unsigned char)3);
    t3 = t21;
    goto LAB35;

LAB36:    t7 = (t0 + 1192U);
    t14 = *((char **)t7);
    t16 = (1 - 2);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t7 = (t14 + t19);
    t12 = *((unsigned char *)t7);
    t13 = (t12 == (unsigned char)2);
    t4 = t13;
    goto LAB38;

}


extern void work_a_1991163692_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1991163692_3212880686_p_0};
	xsi_register_didat("work_a_1991163692_3212880686", "isim/final_test_bench_isim_beh.exe.sim/work/a_1991163692_3212880686.didat");
	xsi_register_executes(pe);
}
