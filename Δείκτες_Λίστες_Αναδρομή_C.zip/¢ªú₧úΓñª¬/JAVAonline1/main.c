#include <stdio.h>
#include <stdlib.h>

struct LIST{
    int value;
    struct LIST* next;
};

typedef struct LIST list;
typedef struct LIST* listptr;

int ListSize(void);
listptr CreationList(int N, listptr head);
listptr findAndPushBack(int n, listptr node);
void printList(listptr ptr);
void freememory(listptr node, listptr ptr);

listptr head=NULL;
listptr ptr=NULL;

int main()
{
    int N, n;

    N=ListSize();

    head=CreationList(N,head);

    ptr=head;

    printList(ptr);

    printf("\n\nEnter a value to search: ");
    scanf("%d",&n);

    head=findAndPushBack(n, head);

    ptr=head;

    printList(ptr);

    freememory(head, ptr);

    return 0;
}

int ListSize(void){
    int size;

    printf("Enter the number of the values: ");
    scanf("%d", &size);

    do{
        if(size<=0){
            printf("\nPlease try again: ");
            scanf("%d",&size);
        }
    }while(size<=0);

    return size;
}

listptr CreationList(int N, listptr head){

    int i, z;
    listptr new_node=NULL;
    listptr ptr=NULL;

    for(i=0; i<N; i++){

        new_node=(listptr)malloc(sizeof(list));

        if(new_node==NULL){
            printf("Unable to allocate memory!\n");
        }
        printf("Enter the value of the node: ");
        scanf("%d",&z);

        new_node->value=z;

        if(head==NULL){
            new_node->next=NULL;
            head=new_node;
        }
        else{
            ptr=head;

            while(ptr->next!=NULL){
                ptr=ptr->next;
            }
            new_node->next=ptr->next;
            ptr->next=new_node;
        }
    }
    return head;
}

listptr findAndPushBack(int n, listptr node){

    listptr ex=node;
    listptr tmp2=node;
    listptr prev=node;

    while(ex->value!=n && ex->next!=NULL){
        ex=ex->next;
    }
    if(ex->value!=n){
        printf("\nThere is no number %d in the list.\n",n);
    }
    if(ex->value==n && ex->next==NULL){
        printf("\nNumber %d is at the end of the list.\n",n);
    }
    if(ex->value==n && ex->next!=NULL && ex->value!=node->value){

        while(prev->next->value!=n){

            prev=prev->next;
        }
        if(ex->value < ex->next->value){

            while(tmp2->next!=NULL){
                tmp2=tmp2->next;
            }

            prev->next=ex->next;
            ex->next=tmp2->next;
            tmp2->next=ex;

            printf("\nValue %d has been moved at the end of the list\n",ex->value);
        }
        else{
            printf("\nValue %d is greater than value %d\n",ex->value, ex->next->value);
        }
    }
    if(ex->value==n && ex->next!=NULL && ex->value==node->value){
        while(tmp2->next!=NULL){
                tmp2=tmp2->next;
            }
        node=ex->next;
        ex->next=tmp2->next;
        tmp2->next=ex;

        printf("\nValue %d has been moved at the end of the list\n",ex->value);
    }
    return node;
}

void printList(listptr ptr){
    while(ptr!=NULL){
        printf("\t%d",ptr->value);
        ptr=ptr->next;
    }
}

void freememory(listptr node, listptr ptr){
    while(ptr!=NULL){
        node=node->next;
        free(ptr);
        ptr=node;
    }
    if(node==NULL){
        printf("\nMemory is empty");
    }
    else{
        printf("\nCould't clean memory");
    }
}




