#include <stdio.h>
#include <stdlib.h>

struct LIST{
    int value;
    struct LIST* next;
};

typedef struct LIST list;
typedef struct LIST* listptr;

listptr head=NULL;
listptr ptr=NULL;

int ListSize(void);
listptr CreationList(int N, listptr head);
void printList(listptr ptr);
int checkAgainstLast(listptr node);
void freememory(listptr node, listptr ptr);

int main()
{
    int N, k;

    N=ListSize();

    head=CreationList(N, head);

    ptr=head;

    printList(ptr);

    printf("\n\n");

    k=checkAgainstLast(ptr);

    ptr=head;

    freememory(head, ptr);

    return 0;
}

int ListSize(void){
    int size;

    printf("Enter the number of the values: ");
    scanf("%d", &size);

    do{
        if(size<=0){
            printf("\nPlease try again: ");
            scanf("%d",&size);
        }
    }while(size<=0);

    return size;
}

listptr CreationList(int N, listptr head){

    listptr ptr=NULL;
    listptr new_node=NULL;
    int i, z;

    for(i=0; i<N; i++){

        new_node=(listptr)malloc(sizeof(list));

        if(new_node==NULL){
            printf("Unable to allocate memory!\n");
        }
        printf("Enter the value of the node: ");
        scanf("%d",&z);

        new_node->value=z;

        if(head==NULL){
            new_node->next=NULL;
            head=new_node;
        }
        else{
            new_node->next=head;
            head=new_node;
        }
    }
    return head;
}

void printList(listptr ptr){
    while(ptr!=NULL){
        printf("\t%d",ptr->value);
        ptr=ptr->next;
    }
}

int checkAgainstLast(listptr node){
    int k;
    listptr tmp=node;

    if(tmp->next!=NULL){
        k=checkAgainstLast(tmp->next);
    }
    else{
        printf("\t%d (No)",tmp->value);
        return tmp->value;
    }
    if(tmp->value > k){
        printf("\t%d (Yes)",tmp->value);
        return k;
    }
    else{
        printf("\t%d (No)",tmp->value);
        return k;
    }
}

void freememory(listptr node, listptr ptr){
    while(ptr!=NULL){
        node=node->next;
        free(ptr);
        ptr=node;
    }
    if(node==NULL){
        printf("\nMemory is empty");
    }
    else{
        printf("\nCould't clean memory");
    }
}


