package askisi_2;


public class BinarySearchTree {
	private int counter=0;
	private int[] tree;
	private int[] arrayOrder;
	public static final int pages=(10000/128)+1;
	
	public BinarySearchTree() {
		tree=new int[10000000];
		arrayOrder=new int[10000];
	}
	
	 public int insert(int key) {
		    int count=0;
		    int pos = 0;
		   
		    while (pos<=10000000 && tree[pos]!=0) {		        
		        if (tree[pos] < key) {
		            count++;
		            pos = 2 * pos + 2;  //right child
		        } else {
		            count++;
		            pos = 2 * pos + 1;  //left child
		        }
		    }
		    //add at the empty position.
		    if(pos<=10000000) {
		     tree[pos] = key;
		    }
		 return count;
	 }
	 
	 public int search(int pos,int key) {
		 if(tree[pos]==0 || tree[pos]==key) {
			 return counter;
		 }
		 if(tree[pos]>key) {
			 counter++;
			 return search(2*pos+1,key);
		 }
		 counter++;
		 return search(2*pos+2,key);
	 }
	 
	 public void inorder(int pos){
		if(pos<=10000000 && tree[pos]!=0) {
			inorder(2*pos+1);
			arrayOrder[counter]=tree[pos];
			counter++;
			inorder(2*pos+2);		
		}
	 }
	 
	 public int RangeQuery(int rt,int K1,int K2,int comparisons){
			if(rt>=10000000 || tree[rt]==0){
				comparisons++;
				return comparisons;
			}			
			 //go right
			 if(K1>tree[rt]){
				 comparisons++;
				 comparisons=RangeQuery(2*rt+2, K1, K2, comparisons);
			 }			
			 //go left
			 else if(tree[rt]>K2){
				 comparisons++;
				 comparisons=RangeQuery(2*rt+1, K1, K2, comparisons);
			 }
			 else if(K1<=tree[rt] && tree[rt]<=K2){
				 comparisons+=2;
				 comparisons=RangeQuery(2*rt+1, K1, K2, comparisons); // go in left sibling and search
				 comparisons=RangeQuery(2*rt+2, K1, K2, comparisons); // go in right sibling and search
			 }
			 return comparisons;
		}
	
	 public void resetCounter() {
		 this.counter=0;
	 }

	 public int getCounter() {
		 return counter;
	 }

	 public int[] getArrayOrder() {
		  return arrayOrder;
	 }

}
