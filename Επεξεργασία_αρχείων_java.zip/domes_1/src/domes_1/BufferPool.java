package domes_1;

import java.util.LinkedList;

public class BufferPool {

	LinkedList<int []> bufferPool;

	public BufferPool() {
		super();
		this.bufferPool =new LinkedList<>();
	}

	public LinkedList<int[]> getBufferPool() {
		return bufferPool;
	}

	public void setBufferPool(LinkedList<int[]> bufferPool) {
		this.bufferPool = bufferPool;
	}
	
}