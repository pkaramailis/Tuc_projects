package domes_1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Random;

public class FileManager {
	private static final int DataPageSize = 512;
	private RandomAccessFile MyFile;
	private long seek;
	private int pages=1; //��������� ��� � ����� ������ ���� ������� �� �� �������� ���.
	
	public void  updateInf(int numOfPages, long seek) throws IOException{	
		ByteArrayOutputStream bos = new ByteArrayOutputStream() ;
		DataOutputStream out = new DataOutputStream(bos);
		out.writeInt(numOfPages);
		out.writeLong(seek);
		out.close();

		// Get the bytes of the serialized object
		byte[] buf = bos.toByteArray(); // Creates a newly allocated byte array.
		
		long k=MyFile.getFilePointer(); //leitourgei ws stack
		// write to the file
		MyFile.seek(0);		
		MyFile.write(buf);
		
		MyFile.seek(k);
	}
	
	public int FileHandle() throws IOException {		
		byte[] buf = new byte[4];
		MyFile.seek(0);
		MyFile.read(buf);
		
		ByteArrayInputStream bis= new ByteArrayInputStream(buf);
		DataInputStream ois= new DataInputStream(bis);
		int page=ois.readInt();

		return page;
	}
	
	public void createFile(String nameOfFile) throws IOException{		
		 RandomAccessFile MyFile = new RandomAccessFile (nameOfFile, "rw");		 
		 ByteArrayOutputStream bos = new ByteArrayOutputStream();
		 DataOutputStream out = new DataOutputStream(bos);
		 
		 out.writeInt(1);
		 //out.writeLong(0);
		 //kai na valw sto for loop mexri to 125, tha doume 
		 for(int i=0; i<127; i++){
			 out.writeInt(0);			 
		 }
		 byte[] buf = bos.toByteArray(); 
		 MyFile.write(buf);	
		 //System.out.println(MyFile.getFilePointer());
		// updateInf(pages, MyFile.getFilePointer()); //�� ����� �� ��������� ��� ��������� ������ ��� ��������� ��� ������ ������� ��� �� �������� ������
		 bos.reset();
		 Random rand = new Random();			
			int k=0;			
			for(int j=0; j<=7812; j++){
				if(j==7812){
					for(int i=0; i<64; i++){
						int  n = rand.nextInt(1000000) + 1;
						out.writeInt(n);
						//System.out.println(n);
						k=k+1;
						
					}
					for(int i=0; i<64; i++){ //estw oti vazoume ayto
						out.writeInt(0);
						//System.out.println(n);
						k=k+1;
					}
					buf = bos.toByteArray(); 
					
					MyFile.write(buf);
					bos.reset();
					pages++;
					continue;
				}
				for(int i=0; i<128; i++){
					int  n = rand.nextInt(1000000) + 1;
					out.writeInt(n);
					//System.out.println(n);
					k=k+1;
				}
				 buf = bos.toByteArray(); 
				 MyFile.write(buf);
				 bos.reset();
				pages++;
			}
			//System.out.println(MyFile.getFilePointer());
			out.close();
			//System.out.println(k); //elegxos ��� �� �� ����� 1.000.000 �� �������
			//System.out.println(pages);	//elegxos ��� �� �� ����� 7814 �������
			//System.out.println("buf size "+ buf.length); //elegxos, ��� �� ������� ��� buf(512)
			//fileHandle(nameOfFile, pages, MyFile.getFilePointer());
			//openFile(nameOfFile,"rw"); //���� ��� � ���� ������ ����������4.000.512 ������ ���� ����� � ������� ��� �����
		    MyFile.seek(0);
		    MyFile.writeInt(pages);
		    //updateInf(pages, MyFile.getFilePointer()); //pigainei to seek sto 4, afou egrapse enan int
		    MyFile.close();
	}
	
	public int openFile(String nameOfFile, String reason) throws FileNotFoundException, IOException{ // Read from file ton arithmo twn selidwn synolika
		MyFile = new RandomAccessFile (nameOfFile, reason);
		byte[] buf = new byte[4];
		MyFile.seek(0);
		MyFile.read(buf);
		
		ByteArrayInputStream bis= new ByteArrayInputStream(buf);
		DataInputStream ois= new DataInputStream(bis);
		
		int numOfPages=ois.readInt();
		//long deiktis=ois.readLong(); //se periptwsi pou tha ithela na dw pou einai ana pasa stigmi to seek
		//System.out.println(deiktis);
		
		return numOfPages;
	}
	
	public int[] readBlock(int page) throws IOException{
		System.out.println("Selected page: ");
		byte[] buf=new byte[DataPageSize];
		int[] buffer=new int[128];
		this.seek=page*512;
		MyFile.seek(this.seek);
		//System.out.println(MyFile.getFilePointer());
		MyFile.read(buf);
		ByteArrayInputStream bis= new ByteArrayInputStream(buf);
		DataInputStream ois= new DataInputStream(bis);
		for(int i=0;i<128;i++) {
			buffer[i]=ois.readInt();
			System.out.println(buffer[i]); //komple
		}
		//System.out.println(MyFile.getFilePointer());
		//System.out.println(pages); // komple leiourgei
		updateInf(pages, MyFile.getFilePointer());
		System.out.println("=======================================================");
		return buffer;
	}
	
	public int[] readBlock2(int page) throws IOException{
		//System.out.println("Selected page: ");
		byte[] buf=new byte[DataPageSize];
		int[] buffer=new int[128];
		this.seek=page*512;
		MyFile.seek(this.seek);
		//System.out.println(MyFile.getFilePointer());
		MyFile.read(buf);
		ByteArrayInputStream bis= new ByteArrayInputStream(buf);
		DataInputStream ois= new DataInputStream(bis);
		for(int i=0;i<128;i++) {
			buffer[i]=ois.readInt();
			//System.out.println(buffer[i]); //komple
		}
		//System.out.println(MyFile.getFilePointer());
		//System.out.println(pages); // komple leiourgei
		updateInf(pages, MyFile.getFilePointer());
		//System.out.println("=======================================================");
		return buffer;
	}
	
	public int[] readNextBlock() throws IOException{
		System.out.println("Next page: ");
		byte[] buf=new byte[DataPageSize];
		int[] buffer=new int[128];
		MyFile.seek(this.seek+512);
		//System.out.println(this.seek);
		MyFile.read(buf);
		ByteArrayInputStream bis= new ByteArrayInputStream(buf);
		DataInputStream ois= new DataInputStream(bis);
		for(int i=0;i<128;i++) {
			buffer[i]=ois.readInt();
			System.out.println(buffer[i]); //komple
		}
		updateInf(pages, MyFile.getFilePointer());
		System.out.println("=======================================================");
		return buffer;
	}
	
	public int[] readPrevBlock() throws IOException{
		System.out.println("Previous page: ");
		byte[] buf=new byte[DataPageSize];
		int[] buffer=new int[128];
		MyFile.seek(this.seek-512);
		MyFile.read(buf);
		ByteArrayInputStream bis= new ByteArrayInputStream(buf);
		DataInputStream ois= new DataInputStream(bis);
		for(int i=0;i<128;i++) {
			buffer[i]=ois.readInt();
			System.out.println(buffer[i]);
		}
		updateInf(pages, MyFile.getFilePointer());
		System.out.println("=======================================================");
		return buffer;
	}
	
	public void writeBlock(int page) throws IOException{		
		if(page==0){ //�� ��� ������ ���� ���� ����� ������ �� ��� �����������
			page++;
		}		
		byte[] buf=new byte[DataPageSize];
		int[] buffer=new int[128];	
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(bos);		
		Random rand = new Random();	
		
		for(int i=0; i<128; i++){
			buffer[i] = rand.nextInt(1000000) + 1;
			out.writeInt(buffer[i]);
		} 
		out.close();
		buf = bos.toByteArray(); 		
		//System.out.println(buf.length); //���������� ��� �� buf ����� 512
		this.seek=page*512;
		MyFile.seek(this.seek);
		MyFile.write(buf);
		
		if(page>this.pages) {
			int npages=page-this.pages;
			this.pages=this.pages+npages;		
		}
		updateInf(this.pages, MyFile.getFilePointer());
	}
	
	public void writeNextBlock() throws IOException{
		byte[] buf=new byte[DataPageSize];
		int[] buffer=new int[128];		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(bos);		
		Random rand = new Random();	
		
		for(int i=0; i<128; i++){
			buffer[i] = rand.nextInt(1000000) + 1;
			out.writeInt(buffer[i]);
		} 
		out.close();
		buf = bos.toByteArray(); 		
		//System.out.println(buf.length); //���������� ��� �� buf ����� 512
		MyFile.seek(this.seek+512);
		MyFile.write(buf);
		
		if(((this.seek+512)/512)>pages) {
			pages++;		
		}
		updateInf(pages, MyFile.getFilePointer());
	}
	
	public void appendBlock() throws IOException{
		byte[] buf=new byte[DataPageSize];
		int[] buffer=new int[128];		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(bos);		
		Random rand = new Random();	
		
		for(int i=0; i<128; i++){
			buffer[i] = rand.nextInt(1000000) + 1;
			out.writeInt(buffer[i]);
		} 
		out.close();
		buf = bos.toByteArray();
		//System.out.println(buf.length); //���������� ��� �� buf ����� 512
		//System.out.println(MyFile.length() + "   append before");
		MyFile.seek((pages*512)); //pages epeidi einai o synolikos arithmos
		//System.out.println(MyFile.getFilePointer());
		MyFile.write(buf);
		//System.out.println(MyFile.length() + "   append after");
		pages++;		
		updateInf(pages, MyFile.getFilePointer());
	}
	
	public void deleteBlock(int pages) throws IOException{ //douleyei swsta, gt an valoume ws orisma sthn readBlock to pages vgazei midenika, ara pairnei thn teleytaia selida tou arxeiou
		int[] buf2= readBlock2(this.pages-1);		
		byte[] buf = new byte[DataPageSize];
		ByteArrayOutputStream bos = new ByteArrayOutputStream() ;
		DataOutputStream out = new DataOutputStream(bos);
		for(int i=0;i<128;i++) {	
			out.writeInt(buf2[i]);
			//System.out.println(buf2[i]);
		}
		buf=bos.toByteArray();	
		MyFile.seek(pages*512);
		MyFile.write(buf);	
		this.pages--;
		//System.out.println(MyFile.length()+"   before delete"); //4.000.768
		MyFile.setLength(this.pages*512);
		//System.out.println(MyFile.length()+"   after delete");  //4.000.256
		updateInf(this.pages, MyFile.getFilePointer());
	}
	
	public void closeFile() throws IOException{
		MyFile.close();
	}
	
}
