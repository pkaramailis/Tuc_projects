package domes_1;

import java.io.IOException;
import java.util.Random;

import tuc.ece.cs102.util.StandardInputRead;

public class MainClass {

	public static void main(String[] args) throws IOException {
		
	FileManager fm = new FileManager();
	PoolManager pm =new PoolManager();
	BufferPool bufferPool=new BufferPool();
	
	int userOption = 0;
	StandardInputRead reader = new StandardInputRead();
	while (userOption!=10){ 
		 printMenu();
         String userInput = reader.readString("What would you like to do? ");
            if (userInput == null) {
                continue;
            } else {
                try {
                    userOption = Integer.parseInt(userInput);
                } catch (NumberFormatException ex) {
                    userOption = 0;
                }
            }
            switch (userOption) {
                case 0:
                    continue;
                case 1:	        
                	 String nameOfFile = reader.readString("Give the name o the file: ");
                	 int k=fm.openFile(nameOfFile, "rw");
                	 //System.out.println(k + "!"); //������� ��� �� �� ���������� ���� � openFile(7814!)
                	 System.out.println("You opened file "+nameOfFile+" successfully");
                    reader.readString("Press any key to continue...");
                    break;
                case 2:
                	nameOfFile = reader.readString("Give the name o the file: ");
                	fm.createFile(nameOfFile);
                	System.out.println("You created file "+nameOfFile+" successfully");
                	reader.readString("Press any key to continue...");
                    break;
                case 3:
                	int page = reader.readPositiveInt("Give the number of the page: ");
                	fm.readBlock(page);
                	fm.readNextBlock();
                	fm.readPrevBlock();
                    reader.readString("Press any key to continue...");
                    break;	                
                case 4:
                	int z=fm.FileHandle();
                	System.out.println("The file has "+z+" pages");
                	reader.readString("Press any key to continue...");
                	break;
                case 5:
                	page = reader.readPositiveInt("Give the number of the page: ");
                	fm.writeBlock(page);
                	fm.writeNextBlock();
                	System.out.println("Pages "+page+","+(page+1)+" wrote successfully");
                	reader.readString("Press any key to continue...");
                	break;	
                case 6:
                	fm.appendBlock();
                	System.out.println("Page wrote successfully");
                	reader.readString("Press any key to continue...");
                	break;
                case 7:
                	page = reader.readPositiveInt("Give the number of the page: ");
                	fm.deleteBlock(page); 
                	System.out.println("Page deleted successfully");
                	reader.readString("Press any key to continue...");
                	break;
                case 8:
                	int g=searchFile(fm);
                	System.out.println("The average of the accesses is: "+g);
                	reader.readString("Press any key to continue...");
                	break;
                case 9:
                	page = reader.readPositiveInt("Give the number of the pages: ");
                	g=searchBufferPool(fm,pm,page);
                	System.out.println("The average of the accesses using pool is: "+g);
                	reader.readString("Press any key to continue...");
                	break;
                case 10:
                	fm.closeFile();
                	System.out.println("Thanks for using programm");
                    return;
                default:	                    
                    System.out.println("User option " + userOption + " ignored...");
                    continue;
            }
	}
	
	
	}
	
	public static void printMenu() {
        System.out.println("                     SERVICES:");
        System.out.println("=======================================================");
        System.out.println("1. Open file...........................................");
        System.out.println("2. Create file.........................................");
        System.out.println("3. Read a page, the next and the previous..............");        
        System.out.println("4. Pages of File......................................."); 
        System.out.println("5. Write a page and the next one.......................");
        System.out.println("6. Write a page at the end of the file.................");
        System.out.println("7. Delete a page.......................................");
        System.out.println("8. Accesses............................................");
        System.out.println("9. Accesses using Buffer Pool..........................");
        System.out.println("10. Close file.........................................");
        System.out.println("=======================================================");
    }
	
	public static int searchFile(FileManager fm) throws IOException{
		int allPages=fm.FileHandle();
		//System.out.println(allPages + "!!!!");
		int accesses=1;
		Random rand = new Random();
		
		for(int i=0; i<1000; i++){
			int sum=0;
			int fsum=0;
			int  n = rand.nextInt(1000000) + 1;
			for(int j=1; j<allPages; j++){
				accesses++;
				sum=0;
				fsum=0;
				int[] buf= fm.readBlock2(j);
				for(int q=0; q<128; q++){
					//System.out.println(buf[q]+"jh");
					if(n!=buf[q]){
						sum++;
						fsum++;
					}
					else{
						fsum++;
						break;
					}
				}
				//System.out.println("========================================");
				if(fsum!=sum){
					break;
				}
			}
		}				
		return (accesses/1000);
	}
	
	public static int searchFile2(FileManager fm, int n) throws IOException{
		int allPages=fm.FileHandle();
		//System.out.println(allPages + "!!!!");
		int accesses=1;
		Random rand = new Random();
		int sum=0;
		int fsum=0;
		
			for(int j=1; j<allPages; j++){
				accesses++;
				sum=0;
				fsum=0;
				int[] buf= fm.readBlock2(j);
				for(int q=0; q<128; q++){
					//System.out.println(buf[q]+"jh");
					if(n!=buf[q]){
						sum++;
						fsum++;
					}
					else{
						fsum++;
						break;
					}
				}
				//System.out.println("========================================");
				if(fsum!=sum){
					break;
				}
			}
		return accesses;
	}
	
	public static int searchBufferPool(FileManager fm,PoolManager p,int k) throws IOException{
		p.createPool(k,fm);
		Random rand=new Random();
		int sum=0;
		for(int i=0;i<1000;i++){
			int num=rand.nextInt(1000000);
			int s=p.searchPool(num);
			if(s==0){
				s=searchFile2(fm,num);
				p.insertPool(fm.readBlock2(s));
			}
			sum=sum+s;
		}
		return sum/1000;
		
	}


}
