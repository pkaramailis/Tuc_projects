package domes_1;

import java.io.IOException;

public class PoolManager {
	BufferPool buffer;
	
	public void createPool(int pages,FileManager fm) throws IOException{
		buffer=new BufferPool();
		
		for(int i=1; i<=pages; i++){
			buffer.getBufferPool().add(fm.readBlock2(i));
		}			
	}
	
	public int searchPool(int n) throws IOException{		
		for(int i=0; i<buffer.getBufferPool().size(); i++){
			int [] buf=buffer.getBufferPool().get(i);
			for(int h=0; h<buf.length; h++){
				if(buf[h]==n)
					return 1;
			}
		}
		return 0;				
	}
	
	public void insertPool(int []page) {		
		buffer.getBufferPool().removeLast();
		buffer.getBufferPool().addFirst(page);		
	}
	
	public void deletePool(int page) {		
		buffer.getBufferPool().remove(page);
	}
	
	public void freePool(int allPages){ 		
		for(int i=0; i<allPages; i++)
			buffer.getBufferPool().remove(i);
	}
}