package tuc.ece.cs102.softwarecompany;

import tuc.ece.cs102.list.Item;
import tuc.ece.cs102.list.Node;
import tuc.ece.cs102.list.SortedList;

public class CompanySortedList extends SortedList {

	public CompanySortedList() {
		super();
	}
	
	public Item search(int key){ //anazitei int
		Node tmpNode = head;
		while (tmpNode != null){
			if (tmpNode.getValue().key().equals(new Integer(key))){
				return tmpNode.getValue();
			}
			tmpNode = tmpNode.getNext();
		}
		return null;
	}
	
	public Item search2(String key){ //anazitei String
		Node tmpNode = head;
		while (tmpNode != null){
			if (tmpNode.getValue().key().equals(new String(key))){
				return tmpNode.getValue();
			}
			tmpNode = tmpNode.getNext();
		}
		return null;
	}
	
	 public Node delete (Item a) {
		 Node n1 = head, n2 = head;
		 while ((n1 != null) && (!a.equals(n1.getValue()))) {
		 n2 = n1; n1 = n1.getNext();
		 }
		 if (n1 != null) { // found
		 length--;
		 if (n2 != n1) // n1 != head
		 n2.setNext(n1.getNext());
		 else // deleting head
		 head = head.getNext();
		 n1.setNext(null); // memory cleanup
		 }
		 return head;
		}

	
	public void printAllInHierarchy(String className){
		Node tmp = head;
		try{
			while (tmp!=null){
				Item item = tmp.getValue();				
				if (Class.forName(className).isInstance(item.getData())){
					item.print();
				}
				tmp = tmp.getNext();
			}
		}catch (ClassNotFoundException ex){
			System.out.println("This class "+className+" does not exist...");
		}
		
	}
		
}
