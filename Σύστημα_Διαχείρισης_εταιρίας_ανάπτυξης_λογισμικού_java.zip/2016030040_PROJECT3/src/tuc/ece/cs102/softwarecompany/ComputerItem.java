package tuc.ece.cs102.softwarecompany;

import tuc.ece.cs102.list.Item;
import tuc.ece.cs102.softwarecompany.model.computers.Computer;

public class ComputerItem extends Item{

	private Computer computer;
	
	public ComputerItem(Computer computer) {
		this.computer = computer;
	}
	
	@Override
	public Object key() {
		return this.computer.getSerialNumber();
	}

	@Override
	public boolean equals(Item o) {
		return key().equals(o.key()); 
	}

	@Override
	public boolean less(Item o) {
		if (((Integer) key()).compareTo((Integer) o.key()) < 0)
			return true;
		return false;
	}

	@Override
	public void print() {
		this.computer.print();
	}

	@Override
	public Object getData() {		
		return this.computer;
	}
	
}
