package tuc.ece.cs102.softwarecompany;

import tuc.ece.cs102.list.Item;
import tuc.ece.cs102.softwarecompany.model.personnel.Employee;

public class EmployeeItem extends Item{
	
	private Employee employee;

	public EmployeeItem(Employee employee) {
		this.employee = employee;
	}
	
	@Override
	public boolean equals(Item o) {
		return this.employee.getFullName().equals(((String) o.key()));
	}

	@Override
	public boolean less(Item o) {
		if (((String) key()).compareTo((String) o.key()) < 0)
			return true;
		return false;
	}

	@Override
	public Object key() {
		return this.employee.getFullName();
	}

	@Override
	public void print() {
		this.employee.print();
	}

	@Override
	public Object getData() {
		return this.employee;
	}

}
