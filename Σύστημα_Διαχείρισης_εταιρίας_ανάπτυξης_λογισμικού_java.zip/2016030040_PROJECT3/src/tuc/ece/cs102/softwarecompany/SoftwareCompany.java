package tuc.ece.cs102.softwarecompany;

import java.util.Vector;

import tuc.ece.cs102.list.Item;
import tuc.ece.cs102.softwarecompany.model.computers.Computer;
import tuc.ece.cs102.softwarecompany.model.computers.Desktop;
import tuc.ece.cs102.softwarecompany.model.computers.Laptop;
import tuc.ece.cs102.softwarecompany.model.computers.Server;
import tuc.ece.cs102.softwarecompany.model.computers.Tablet;
import tuc.ece.cs102.softwarecompany.model.personnel.Employee;
import tuc.ece.cs102.softwarecompany.model.personnel.Manager;
import tuc.ece.cs102.softwarecompany.model.personnel.Programmer;
import tuc.ece.cs102.softwarecompany.model.personnel.Secretary;

public class SoftwareCompany{
	
	private String nameOfCompany;
	private String yearOf�stablishment;
	private String url;
	
	private CompanySortedList listOfEmployees;
	private CompanySortedList listOfComputers;
	
	
	public SoftwareCompany() { //arxikopoiisi tis etairias
		this.nameOfCompany = "Pakos S.A.";
		this.yearOf�stablishment = "1998";
		this.url = "707";
		
		listOfEmployees = new CompanySortedList();
		listOfComputers = new CompanySortedList();
		
		Vector<String> listOfProjects = new Vector<String>();
		listOfProjects.add("ereuna");
		listOfProjects.add("emporiko");
		listOfProjects.add("odiko diktio");
		
		listOfComputers.insert(new ComputerItem(new Server(111, "apple", 1200, "ios", "32bit", 8, 1)));
		listOfComputers.insert(new ComputerItem(new Server(222, "apple", 1800, "ios", "64bit", 16, 2)));
		listOfComputers.insert(new ComputerItem(new Desktop(333, "linux", 700, "linux32",200,"eclipse")));
		listOfComputers.insert(new ComputerItem(new Desktop(666, "apple", 1100, "ios",300,"eclipse")));
		listOfComputers.insert(new ComputerItem(new Desktop(777, "windows", 780, "windows8",400,"eclipse")));
		listOfComputers.insert(new ComputerItem(new Laptop(444, "windows", 900, "windows10", 16, "hdmi")));
		listOfComputers.insert(new ComputerItem(new Tablet(555, "windows", 1100, "windows10", 14, 2000 )));
		
		listOfEmployees.insert(new EmployeeItem(new Programmer("takis", "6985022233", "tramp", 8000, "java", findDesktop2(), "oikodomi")));
		listOfEmployees.insert(new EmployeeItem(new Programmer("marios", "6985023333", "kapsis", 2000, "java", findDesktop2(), "treno")));
		listOfEmployees.insert(new EmployeeItem(new Manager("adonis", "6985999999", "superdry", 6000, "java", findDesktop2(), "treno", listOfProjects,"@","634565")));
		listOfEmployees.insert(new EmployeeItem(new Manager("basilis", "6944444444", "kapsis", 9000, "java", findDesktop2(), "treno", listOfProjects,"@","34252")));
		listOfEmployees.insert(new EmployeeItem(new Secretary("maritina", "6985443344", "roumeli", 500, "sales")));
	}	
	
	public String getNameOfCompany() {
		return nameOfCompany;
	}
	public void setNameOfCompany(String nameOfCompany) {
		this.nameOfCompany = nameOfCompany;
	}
	public String getYearOf�stablishment() {
		return yearOf�stablishment;
	}
	public void setYearOf�stablishment(String yearOf�stablishment) {
		this.yearOf�stablishment = yearOf�stablishment;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	public CompanySortedList getListOfEmployees() {
		return listOfEmployees;
	}

	public void setListOfEmployees(CompanySortedList listOfEmployees) {
		this.listOfEmployees = listOfEmployees;
	}

	public CompanySortedList getListOfComputers() {
		return listOfComputers;
	}

	public void setListOfComputers(CompanySortedList listOfComputers) {
		this.listOfComputers = listOfComputers;
	}	
	
	public void addComputer(Computer computer){		
		listOfComputers.insert(new ComputerItem(computer));
	}

	public void addEmployee(Employee employee) {
		listOfEmployees.insert(new EmployeeItem(employee));		
	}
	
	public Computer searchForComputer(int serialNumber){  //anazitei enan computer me vasi to seiriako arithmo
		ComputerItem computerItem = (ComputerItem)listOfComputers.search(serialNumber);
		if (computerItem!=null){		
			return(Computer)computerItem.getData();
		}else{
			return null;
		}
	}
	
	public void print(){
		System.out.println("Name of company: " + getNameOfCompany());
		System.out.println("Year of establishment: " + getYearOf�stablishment());
		System.out.println("URL: " + getUrl());
		System.out.println("Number of computers: " + listOfComputers.getLength());
		System.out.println("Number of employees: " +listOfEmployees.getLength());
	}
	
	public ComputerItem searchForComputer2(int serialNumber){ //idio me tin kanoniki apla epistrefei typo item kai xrisimopoieitai gia tin diagrafi
		ComputerItem computerItem = (ComputerItem)listOfComputers.search(serialNumber);
		if (computerItem!=null){		
			return computerItem;
		}else{
			return null;
		}
	}
	
	public EmployeeItem searchForEmployee(String fullName){
		EmployeeItem employeeItem = (EmployeeItem)listOfEmployees.search2(fullName); //i search2 anazitei string enw i search int
		if (employeeItem!=null){		
			return employeeItem;
		}else{
			return null;
		}
	}
	
	public Desktop searchForDesktop(int serialNumber){ //anazitei to desktop me vasi to seiriako arithmo
		ComputerItem computerItem = (ComputerItem)listOfComputers.search(serialNumber);
		if (computerItem!=null){		
			return(Desktop)computerItem.getData();
		}else{
			return null;
		}
	}
	
	public void deleteComputer(Item a){
		listOfComputers.delete(a);
	}
	
	public void deleteEmployee(Item a){
		listOfEmployees.delete(a);
	}
	
	public void printComputersByCategory(String catClass){
		listOfComputers.printAllInHierarchy(catClass);
	}
	
	public void printEmployeesByCategory(String catClass){
		listOfEmployees.printAllInHierarchy(catClass);
	}
	
	public void printDesktops(String catClass){
		listOfComputers.printAllInHierarchy(catClass);
	}
		
	public Desktop findDesktop2(){		//xrisimopoieitai mono stin arxikopoiisi gia na dwsei ws arxiki timi to desktop me seiriako arithmo 333							
		Desktop desktop = searchForDesktop(333);
		if (desktop == null){
			System.out.println("Computer not Found");
			return null;
		}else{
			return desktop;
		}			
	}
	
}