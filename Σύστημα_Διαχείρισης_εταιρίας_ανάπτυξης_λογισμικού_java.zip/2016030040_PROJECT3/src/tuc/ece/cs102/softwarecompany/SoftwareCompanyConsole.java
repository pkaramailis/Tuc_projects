package tuc.ece.cs102.softwarecompany;

import java.util.Vector;
import tuc.ece.cs102.softwarecompany.model.computers.Computer;
import tuc.ece.cs102.softwarecompany.model.computers.Desktop;
import tuc.ece.cs102.softwarecompany.model.computers.Laptop;
import tuc.ece.cs102.softwarecompany.model.computers.Server;
import tuc.ece.cs102.softwarecompany.model.computers.Tablet;
import tuc.ece.cs102.softwarecompany.model.personnel.Employee;
import tuc.ece.cs102.softwarecompany.model.personnel.Manager;
import tuc.ece.cs102.softwarecompany.model.personnel.Programmer;
import tuc.ece.cs102.softwarecompany.model.personnel.Secretary;
import tuc.ece.cs102.util.StandardInputRead;

public class SoftwareCompanyConsole {
	
	private SoftwareCompany softwareCompany;

	public SoftwareCompany getSoftwareCompany() {
		return softwareCompany;
	}

	public void setSoftwareCompany(SoftwareCompany softwareCompany) {
		this.softwareCompany = softwareCompany;
	}
	
	private StandardInputRead reader;
	int userOption;
	
	public SoftwareCompanyConsole() {
		softwareCompany = new SoftwareCompany();
		reader = new StandardInputRead();
		userOption=0;
	}

	public static void main(String[] args) {
		
		SoftwareCompanyConsole scc = new SoftwareCompanyConsole();
			
		
		int userOption = 0;		
		StandardInputRead reader = new StandardInputRead();
		while (userOption!=11){ 
			 printMenu();
	         String userInput = reader.readString("What would you like to do? ");
	            if (userInput == null) {
	                continue;
	            } else {
	                try {
	                    userOption = Integer.parseInt(userInput);
	                } catch (NumberFormatException ex) {
	                    userOption = 0;
	                }
	            }
	            switch (userOption) {
	                case 0:
	                    continue;
	                case 1:   
	                	scc.addNewEmployee();
	                	reader.readString("Press any key to continue...");
	                    break;
	                case 2:
	                	scc.printEmployeeDetails();
	                    reader.readString("Press any key to continue...");
	                    break;	                
	                case 3:
	                	scc.deleteEmployee();
	                	reader.readString("Press any key to continue...");
	                	break;
	                case 4:
	                	scc.addNewComputer();
	            		reader.readString("Press any key to continue...");
	                	break;	
	                case 5:
	                	scc.findComputer();
	                	reader.readString("Press any key to continue...");
	                	break;
	                case 6:
	                	scc.deleteComputer();
	                	reader.readString("Press any key to continue...");
	                	break;
	                case 7:
	                	scc.softwareCompany.print();
	                	reader.readString("Press any key to continue...");
	                	break;
	                case 8:
	                	scc.printEmployeesByCategory();
	                	reader.readString("Press any key to continue...");
	                	break;
	                case 9:
	                	scc.printComputersByCategory();
	                	reader.readString("Press any key to continue...");
	                	break;
	                case 10:
	                	System.out.println("Thanks for using the Software Console...");
	                    break;
	                default:	                    
	                    System.out.println("User option " + userOption + " ignored...");
	                    continue;
	            }
		}
	}
	 
	public static void printMenu() {
        System.out.println("                     Select:");
        System.out.println("=======================================================");
        System.out.println("1. Insert new employee.................................");
        System.out.println("2. Print employee details..............................");        
        System.out.println("3. Delete employee....................................."); 
        System.out.println("4. Insert new computer.................................");
        System.out.println("5. Print computer details..............................");
        System.out.println("6. Delete computer.....................................");
        System.out.println("7. Print company details...............................");
        System.out.println("8. Print employees of the company......................");
        System.out.println("9. Print computers of the company......................");
        System.out.println("10. Exit...............................................");
        System.out.println("=======================================================");
    }
		
	public void addNewComputer() {
        System.out.println("                     Select:");
        System.out.println("=======================================================");
        System.out.println("1. Server..............................................");
        System.out.println("2. Desktop.............................................");
        System.out.println("3. Mobile-->Laptop.....................................");        
        System.out.println("4. Mobile-->Tablet....................................."); 
        System.out.println("5. Exit................................................");
        System.out.println("=======================================================");
        
        int userOption = 0;
    	
		String maker, operatingSystem, processorType, programm, displayPort;
		int serialNumber, cost, memory, disk, processorSpeed;
		float display, batteryMah;
		Computer computer;
		
		StandardInputRead reader = new StandardInputRead();
		while (userOption>5 || userOption<1){ 
	         String userInput = reader.readString("What would you like to do? ");
	            if (userInput == null) {
	                continue;
	            } else {
	                try {
	                    userOption = Integer.parseInt(userInput);
	                } catch (NumberFormatException ex) {
	                    userOption = 0;
	                }
	            }
	            switch (userOption) {
	                case 0:
	                    continue;
	                case 1:	  
	                	serialNumber = reader.readPositiveInt("Give me the serial number: ");
	                	maker = reader.readString("Give me the maker: ");
	                	cost = reader.readPositiveInt("Give me the cost: ");
	                	operatingSystem = reader.readString("Give me the operating system: ");
	                	processorType = reader.readString("Give me the processor type: ");
	                	memory = reader.readPositiveInt("Give me the memory: ");
	                	disk = reader.readPositiveInt("Give me the disk: ");
	                	computer = new Server(serialNumber, maker, cost, operatingSystem, processorType, memory, disk);
	                	softwareCompany.addComputer(computer);
	                	System.out.println("Computer Added...");
	                    break;
	                case 2:
	                	serialNumber = reader.readPositiveInt("Give me the serial number: ");
	                	maker = reader.readString("Give me the maker: ");
	                	cost = reader.readPositiveInt("Give me the cost: ");
	                	operatingSystem = reader.readString("Give me the operating system: ");
	                	processorSpeed = reader.readPositiveInt("Give me the processor speed: ");
	                	programm= reader.readString("Give me the programm: ");
	                	computer = new Desktop(serialNumber, maker, cost, operatingSystem, processorSpeed, programm);
	                	softwareCompany.addComputer(computer);
	                	System.out.println("Computer Added...");
	                    break;
	                case 3:
	                	serialNumber = reader.readPositiveInt("Give me the serial number: ");
	                	maker = reader.readString("Give me the maker: ");
	                	cost = reader.readPositiveInt("Give me the cost: ");
	                	operatingSystem = reader.readString("Give me the operating system: ");
	                	display = reader.readPositiveFloat("Give me the display: ");
	                	displayPort = reader.readString("Give me the display port: ");
	                	computer = new Laptop(serialNumber, maker, cost, operatingSystem, display, displayPort);
	                	softwareCompany.addComputer(computer);
	                	System.out.println("Computer Added...");
	                    break;	                
	                case 4:
	                	serialNumber = reader.readPositiveInt("Give me the serial number: ");
	                	maker = reader.readString("Give me the maker: ");
	                	cost = reader.readPositiveInt("Give me the cost: ");
	                	operatingSystem = reader.readString("Give me the operating system: ");
	                	display = reader.readPositiveFloat("Give me the display: ");
	                	batteryMah = reader.readPositiveFloat("Give me the battery MAh: ");
	                	computer = new Tablet(serialNumber, maker, cost, operatingSystem, display, batteryMah);
	                	softwareCompany.addComputer(computer);
	                	System.out.println("Computer Added...");
	                	break;
	                case 5:
	                	break;
	                default:	                    
	                    System.out.println("User option " + userOption + " ignored...");
	                    continue;
	            }
		}
        
        
    }
	
	public void addNewEmployee() {
        System.out.println("                     Select:");
        System.out.println("=======================================================");
        System.out.println("1. Programmer..........................................");
        System.out.println("2. Manager.............................................");
        System.out.println("3. Secretary...........................................");        
        System.out.println("4. Exit................................................");
        System.out.println("=======================================================");
        
        
        int userOption = 0;    
    	
		String fullName, phone, office, programmingLanguage, project, email, mobilePhone, responsibility;
		float salary;
		Desktop desktop;		
		Employee employee;
	
	StandardInputRead reader = new StandardInputRead();
	while (userOption>4 || userOption<1){ 
         String userInput = reader.readString("What would you like to do? ");
            if (userInput == null) {
                continue;
            } else {
                try {
                    userOption = Integer.parseInt(userInput);
                } catch (NumberFormatException ex) {
                    userOption = 0;
                }
            }
            switch (userOption) {
                case 0:
                    continue;
                case 1:	   
                	fullName = reader.readString("Give me the fullName: ");
                	phone = reader.readString("Give me the phone: ");
                	office = reader.readString("Give me the office: ");
                	salary = reader.readPositiveFloat("Give me the salary: ");
                	programmingLanguage = reader.readString("Give me the programming language: ");
                	printMenu4(); //ektipwnei ola ta desktops
                	desktop = findDesktop();
                	project = reader.readString("Give me the project: ");
                	employee = new Programmer(fullName, phone, office, salary, programmingLanguage, desktop, project);
                	softwareCompany.addEmployee(employee);
                	System.out.println("Employee Added...");
                    break;
                case 2:
                	fullName = reader.readString("Give me the fullName: ");
                	phone = reader.readString("Give me the phone: ");
                	office = reader.readString("Give me the office: ");
                	salary = reader.readPositiveFloat("Give me the salary: ");
                	programmingLanguage = reader.readString("Give me the programming language: ");
                	printMenu4();
                	desktop = findDesktop();
                	project = reader.readString("Give me the project: ");
                	Vector<String> listOfProjects = printMenu5(); //zitaei ews kai 5 projects pou managarei o manager ta vazei se mia lista kai sti sinexeia epistrefei ti lista
                	email = reader.readString("Give me the email: ");
                	mobilePhone = reader.readString("Give me the mobilePhone: ");
                	employee = new Manager(fullName, phone, office, salary, programmingLanguage, desktop, project, 
                			listOfProjects, email, mobilePhone);
                	softwareCompany.addEmployee(employee);
                	System.out.println("Employee Added...");
                    break; 
                case 3:
                	fullName = reader.readString("Give me the fullName: ");
                	phone = reader.readString("Give me the phone: ");
                	office = reader.readString("Give me the office: ");
                	salary = reader.readPositiveFloat("Give me the salary: ");
                	programmingLanguage = reader.readString("Give me the programming language: ");
                	printMenu4();
                	desktop = findDesktop();
                	project = reader.readString("Give me the project: ");
                	responsibility = reader.readString("Give me the responsibility: ");
                	employee = new Secretary(fullName, phone, office, salary, responsibility);
                	softwareCompany.addEmployee(employee);
                	System.out.println("Employee Added...");
                    break;	                
                case 4:
                	break;
                default:	                    
                    System.out.println("User option " + userOption + " ignored...");
                    continue;
            }
		}
    }
	
	public void findComputer(){		//vriskei ton ypologisti kai ektipwnei ta stoixeia tou		
		int key;			
		key = reader.readPositiveInt("Serial number: ");					
		Computer computer = softwareCompany.searchForComputer(key);
		if (computer == null){
			System.out.println("Computer not Found");
		}else{
			computer.print();
		}			
	}
	
	public Desktop findDesktop(){		//zitaei to serial number, vriskei to dekstop kai to epistrefei		
		int key;			
		key = reader.readPositiveInt("Serial number: ");					
		Desktop desktop = softwareCompany.searchForDesktop(key);
		if (desktop == null){
			System.out.println("Computer not Found");
			return null;
		}else{
			return desktop;
		}			
	}
	
	public void deleteComputer(){				
		int key;			
		key = reader.readPositiveInt("Serial number: ");					
		ComputerItem computerItem = softwareCompany.searchForComputer2(key);
		if (computerItem == null){
			System.out.println("Computer not Found");
		}else{
			softwareCompany.deleteComputer(computerItem);
			System.out.println("Computer deleted");
		}			
	}
	
	public void deleteEmployee(){				
		String key;			
		key = reader.readString("Fullname: ");					
		EmployeeItem employeeItem = softwareCompany.searchForEmployee(key);
		if (employeeItem == null){
			System.out.println("Employee not Found");
		}else{
			softwareCompany.deleteEmployee(employeeItem);
			System.out.println("Employee deleted");
		}			
	}
	
	public void printComputersByCategory(){
		String category = reader.readString("What kind of Computers you want to see?");
		softwareCompany.printComputersByCategory(category);
	}	
	
	public void printEmployeesByCategory(){
		String category = reader.readString("What kind of Employees you want to see?");
		softwareCompany.printEmployeesByCategory(category);
	}
	
	public void printDesktopsCategory(){
		String category = "tuc.ece.cs102.softwarecompany.model.computers.Desktop";
		softwareCompany.printDesktops(category);
	}
	
	public void printMenu4(){  //ektipwnei ola ta desktops
		System.out.println("");
    	printDesktopsCategory();
    	System.out.println("Select your desktop");
	}
	
	public void printEmployeeDetails(){ //vriskei ton ipallilo kai ektypwnei ta stoixeia tou
		String fullName = reader.readString("Give me the fullname of the employee: ");
		EmployeeItem employeeItem = softwareCompany.searchForEmployee(fullName);
		if (employeeItem == null){
			System.out.println("Employee not Found");
		}else{
			employeeItem.print();				
		}	
				
	}
	
	public Vector<String> printMenu5(){ //zitaei ews kai 5 projects pou managarei o manager ta vazei se mia lista kai sti sinexeia epistrefei ti lista
		Vector<String> listOfProjects = new Vector<String>();
		int i=0;
		String ManageProject = reader.readString("Give me the project you manage: ");
		listOfProjects.add(ManageProject);
		i++;
		
		while(i<5){
			System.out.println("");
	        System.out.println("Would you like to add an other project?");
	        System.out.println("=======================================================");
	        System.out.println("1. Yes.................................................");
	        System.out.println("2. NO..................................................");
	        System.out.println("=======================================================");
	        
	        int userOption = 0;    
		
		StandardInputRead reader = new StandardInputRead();
		while (userOption>2 || userOption<1){ 
	         String userInput = reader.readString("What would you like to do? ");
	            if (userInput == null) {
	                continue;
	            } else {
	                try {
	                    userOption = Integer.parseInt(userInput);
	                } catch (NumberFormatException ex) {
	                    userOption = 0;
	                }
	            }
	            switch (userOption) {
	                case 0:
	                    continue;
	                case 1:	   
	        			String ManageProject2 = reader.readString("Give me the project you manage: ");
	        			listOfProjects.add(ManageProject2);
	        			i++;	                	
	                    break;             
	                case 2:
	                	i=5;
	                	break;
	                default:	                    
	                    System.out.println("User option " + userOption + " ignored...");
	                    continue;
	            }
			}			
		}
		return listOfProjects;
		
	}
};
