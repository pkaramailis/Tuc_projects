package tuc.ece.cs102.softwarecompany.model.computers;

public abstract class Computer {
	
	private int serialNumber;
	private String maker;
	private int cost;
	private String operatingSystem;
	
	public Computer(int serialNumber, String maker, int cost, String operatingSystem) {
		super();
		this.serialNumber = serialNumber;
		this.maker = maker;
		this.cost = cost;
		this.operatingSystem = operatingSystem;
	}
	
	public Computer(){
		
	}
	
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}
	
	public abstract void print();
	
	public abstract String toString();
}
