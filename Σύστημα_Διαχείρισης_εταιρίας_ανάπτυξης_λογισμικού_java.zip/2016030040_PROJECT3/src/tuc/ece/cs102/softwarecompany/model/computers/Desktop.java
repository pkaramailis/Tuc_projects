package tuc.ece.cs102.softwarecompany.model.computers;


public class Desktop extends Computer {
	
	private int processorSpeed;
	private String programm;
	
	public Desktop(int serialNumber, String maker, int cost, String operatingSystem, int processorSpeed,
			String programm) {
		super(serialNumber, maker, cost, operatingSystem);
		this.processorSpeed = processorSpeed;
		this.programm = programm;
	}
	
	public int getProcessorSpeed() {
		return processorSpeed;
	}
	public void setProcessorSpeed(int processorSpeed) {
		this.processorSpeed = processorSpeed;
	}
	public String getProgramm() {
		return programm;
	}
	public void setProgramm(String programm) {
		this.programm = programm;
	}	

	public void print(){
		System.out.println("Computer>Desktop: " +this.toString());
	}

	@Override
	public String toString() {
		return "Serial number: " + getSerialNumber() + "\t\tMaker: " + getMaker() + "\t\tCost: " + getCost() + "\t\tOperating system: " 
				+ getOperatingSystem() + "\t\tProcessor Speed: " + getProcessorSpeed() + "\t\tProgramm: " +getProgramm();
	}
	
	
}
