package tuc.ece.cs102.softwarecompany.model.computers;

	
public class Laptop extends Mobile {
		
	private String displayPort;
	
	public Laptop(int serialNumber, String maker, int cost, String operatingSystem, float display,
			String displayPort) {
		super(serialNumber, maker, cost, operatingSystem, display);
		this.displayPort = displayPort;
	}

	public String getDisplayPort() {
		return displayPort;
	}
	
	public void setDisplayPort(String displayPort) {
		this.displayPort = displayPort;
	}
	
	public void print() {
		System.out.println("Computer>Mobile>Laptop: "+ this.toString());
	}
	
	public String toString() {
		return "Serial number: " + getSerialNumber() + "\t\tMaker: " + getMaker() + "\t\tCost: " + getCost() + "\t\tOperating system: " 
				+ getOperatingSystem() + "\t\tDisplay: " + getDisplay() + "\t\tDisplay port: " +getDisplayPort();
	}
	
}
