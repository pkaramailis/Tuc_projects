package tuc.ece.cs102.softwarecompany.model.computers;

public abstract class Mobile extends Computer {

	private float display;
	
	public Mobile(int serialNumber, String maker, int cost, String operatingSystem, float display) {
		super(serialNumber, maker, cost, operatingSystem);
		this.display = display;
	}
	
	public float getDisplay() {
		return display;
	}

	public void setDisplay(float display) {
		this.display = display;
	} 
	
	
}
