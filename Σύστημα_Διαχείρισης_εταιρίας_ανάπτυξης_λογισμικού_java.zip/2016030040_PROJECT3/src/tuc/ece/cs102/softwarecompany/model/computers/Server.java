package tuc.ece.cs102.softwarecompany.model.computers;

public class Server extends Computer {
	
	private String processorType;
	private int memory;
	private int disk;
	
	public Server(int serialNumber, String maker, int cost, String operatingSystem, String processorType, int memory,
			int disk) {
		super(serialNumber, maker, cost, operatingSystem);
		this.processorType = processorType;
		this.memory = memory;
		this.disk = disk;
	}
	
	public String getProcessorType() {
		return processorType;
	}
	public void setProcessorType(String processorType) {
		this.processorType = processorType;
	}
	public int getMemory() {
		return memory;
	}
	public void setMemory(int memory) {
		this.memory = memory;
	}
	public int getDisk() {
		return disk;
	}
	public void setDisk(int disk) {
		this.disk = disk;
	}

	public void print(){
		System.out.println("Computer>Server: " +this.toString());
	}

	@Override
	public String toString() {
		return "Serial number: " + getSerialNumber() + "\t\tMaker: " + getMaker() + "\t\tCost: " + getCost() + "\t\tOperating system: " 
	+ getOperatingSystem() + "\t\tProcessor Type: " + getProcessorType() + "\t\tMemory: " +getMemory() + "\t\tDisk: " + getDisk();
	}
}
