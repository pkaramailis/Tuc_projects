package tuc.ece.cs102.softwarecompany.model.computers;

public class Tablet extends Mobile {

	private float batteryMah;	

	public Tablet(int serialNumber, String maker, int cost, String operatingSystem, float display,
			float batteryMah) {
		super(serialNumber, maker, cost, operatingSystem, display);
		this.batteryMah = batteryMah;
	}
	
	public float getBatteryMah() {
		return batteryMah;
	}

	public void setBatteryMah(float batteryMah) {
		this.batteryMah = batteryMah;
	}
	
	public void print() {
		System.out.println("Computer>Mobile>Tablet: "+ this.toString());
	}
	
	public String toString() {
		return "Serial number: " + getSerialNumber() + "\t\tMaker: " + getMaker() + "\t\tCost: " + getCost() + "\t\tOperating system: " 
				+ getOperatingSystem() + "\t\tDisplay: " + getDisplay() + "\t\tBattery Mah: " +getBatteryMah();
	}
}
