package tuc.ece.cs102.softwarecompany.model.personnel;

public abstract class Employee {
	
	private String fullName;
	private String phone;
	private String office;
	private float salary;
	
	public abstract void print();
	public abstract String toString();
	
	public Employee(String fullName, String phone, String office, float salary) {
		super();
		this.fullName = fullName;
		this.phone = phone;
		this.office = office;
		this.salary = salary;
	}
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}

}
