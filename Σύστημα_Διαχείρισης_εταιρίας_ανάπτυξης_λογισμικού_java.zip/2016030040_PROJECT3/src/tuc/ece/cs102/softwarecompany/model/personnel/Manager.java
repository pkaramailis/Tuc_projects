package tuc.ece.cs102.softwarecompany.model.personnel;

import java.util.Vector;

import tuc.ece.cs102.softwarecompany.model.computers.Desktop;

public class Manager extends Programmer {

	private Vector<String> listOfProjects;
	private String email;
	private String mobilePhone;
	
	public Manager(String fullName, String phone, String office, float salary, String programmingLanguage,
			Desktop desktop, String project, Vector<String> listOfProjects, String email, String mobilePhone) {
		super(fullName, phone, office, salary, programmingLanguage, desktop, project);
		this.listOfProjects = listOfProjects;
		this.email = email;
		this.mobilePhone = mobilePhone;
	}
		
	public Vector<String> getListOfProjects() {
		return listOfProjects;
	}
	public void setListOfProjects(Vector<String> listOfProjects) {
		this.listOfProjects = listOfProjects;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	
	public void print() {
		System.out.println("Employee>Programmer>Manager "+this.toString());
	}
	
	public String toString() {
		return "Fullname: " + getFullName() + "\t\tPhone: " + getPhone() + "\t\tOffice: " + getOffice() + "\t\tSalary: " + getSalary()
		+ "\t\tList of projects: " +getListOfProjects() +"\t\tEmail: " +getEmail() +"\t\tMobilephone: " +getMobilePhone();
	}
	
}
