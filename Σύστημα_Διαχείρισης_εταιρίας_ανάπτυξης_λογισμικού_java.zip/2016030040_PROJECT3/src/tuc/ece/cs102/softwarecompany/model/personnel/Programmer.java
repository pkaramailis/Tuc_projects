package tuc.ece.cs102.softwarecompany.model.personnel;

import tuc.ece.cs102.softwarecompany.model.computers.Desktop;

public class Programmer extends Employee {

	private String programmingLanguage;
	private Desktop desktop;
	private String project;
	
	public Programmer(String fullName, String phone, String office, float salary, String programmingLanguage,
			Desktop desktop, String project) {
		super(fullName, phone, office, salary);
		this.programmingLanguage = programmingLanguage;
		this.desktop = desktop;
		this.project = project;
	}
	
	public String getProgrammingLanguage() {
		return programmingLanguage;
	}
	public void setProgrammingLanguage(String programmingLanguage) {
		this.programmingLanguage = programmingLanguage;
	}
	public Desktop getDesktop() {
		return desktop;
	}
	public void setDesktop(Desktop desktop) {
		this.desktop = desktop;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}

	@Override
	public void print() {
		System.out.println("Employee>Programmer "+this.toString());
	}

	@Override
	public String toString() {
		return "Fullname: " + getFullName() + "\t\tPhone: " + getPhone() + "\t\tOffice: " + getOffice() + "\t\tSalary: " + getSalary()
		+ "\t\tProgramming language: " +getProgrammingLanguage() + "\t\tDesktop: " + getDesktop() + "\t\tProject: " + getProject();
	}
	
}
