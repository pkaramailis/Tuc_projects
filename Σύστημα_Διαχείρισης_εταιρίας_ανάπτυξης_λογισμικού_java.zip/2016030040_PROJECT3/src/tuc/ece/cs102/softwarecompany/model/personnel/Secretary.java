package tuc.ece.cs102.softwarecompany.model.personnel;

public class Secretary extends Employee {

	private String responsibility;

	public Secretary(String fullName, String phone, String office, float salary, String responsibility) {
		super(fullName, phone, office, salary);
		this.responsibility = responsibility;
	}

	public String getResponsibility() {
		return responsibility;
	}

	public void setResponsibility(String responsibility) {
		this.responsibility = responsibility;
	}
	
	public void print() {
		System.out.println("Employee>Secretary "+this.toString());
	}
	
	public String toString() {
		return "Fullname: " + getFullName() + "\t\tPhone: " + getPhone() + "\t\tOffice: " + getOffice() + "\t\tSalary: " + getSalary()
		+ "\t\tResponsibility: " +getResponsibility();
	}
	
	
	
}
