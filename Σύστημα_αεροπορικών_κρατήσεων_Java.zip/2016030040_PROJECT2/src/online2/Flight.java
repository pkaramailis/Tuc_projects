package online2;

import java.util.Vector;
import online2.Reservation;

public class Flight {
	private String flightCode;
	private String nameOfCompany;
	private String internationalDepartureCode;
	private String internationalArrivalCode;
	private int valueOfTicket;
	private int bookedNumOfFlights;
	
	private Vector<Reservation> flightReservations;
	
	public Flight(){
		this.flightReservations = new Vector<Reservation>();
	}
	
	public Flight(String flightCode, String nameOfCompany, String internationalDepartureCode,
			String internationalArrivalCode, int  valueOfTicket) {
		this.flightCode = flightCode;
		this.nameOfCompany = nameOfCompany;
		this.internationalDepartureCode = internationalDepartureCode;
		this.internationalArrivalCode = internationalArrivalCode;
		this.valueOfTicket =  valueOfTicket;
		
		this.flightReservations = new Vector<Reservation>();
	}

	//set and get methodoi
	
	public String getFlightCode() {
		return flightCode;
	}

	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}
	   
	public String getNameOfCompany() {
		return nameOfCompany;
	}

	public void setNameOfCompany(String nameOfCompany) {
		this.nameOfCompany = nameOfCompany;
	}

	public String getInternationalDepartureCode() {
		return internationalDepartureCode;
	}

	public void setInternationalDepartureCode(String internationalDepartureCode) {
		this.internationalDepartureCode = internationalDepartureCode;
	}

	public String getInternationalArrivalCode() {
		return internationalArrivalCode;
	}

	public void setInternationalArrivalCode(String internationalArrivalCode) {
		this.internationalArrivalCode = internationalArrivalCode;
	}

	public int getValueOfTicket() {
		return valueOfTicket;
	}

	public void setValueOfTicket(int valueOfTicket) {
		this.valueOfTicket = valueOfTicket;
	}
	
	public Vector<Reservation> getFlightReservations() { 
		return flightReservations;
	}

	public void setFlightReservations(Vector<Reservation> flightReservations) {
		this.flightReservations = flightReservations;
	}
	
	public void addFlightReservation(Reservation r) {
		flightReservations.add(r);
	}

	public int getBookedNumOfFlights() {
		return bookedNumOfFlights;
	}

	public void setBookedNumOfFlights(int bookedNumOfFlights) {
		this.bookedNumOfFlights = bookedNumOfFlights;
	}
	
	//���������� �������
	
	public void print() {
		      
		System.out.print("Flight code: " + flightCode);
		System.out.print("Name of company: " + nameOfCompany);
		System.out.print("International departure code: " + internationalDepartureCode);
		System.out.print("International arrival code: " + internationalArrivalCode);
		System.out.print("Value of ticket:" + valueOfTicket);
	}
	
	public void println() {
	      
		System.out.println("Flight code: " + flightCode);
		System.out.println("Name of company: " + nameOfCompany);
		System.out.println("International departure code: " + internationalDepartureCode);
		System.out.println("International arrival code: " + internationalArrivalCode);
		System.out.println("Value of ticket:" + valueOfTicket);
	}
	
	public String getFlightInfo(){
		return this.flightCode;
	}
}
