package online2;

import java.util.Vector;
import online2.Reservation;

public class Passenger {
	private String email;
	private String fullName;
	private String telephone;
	private int totalFlightsOfPassenger;
	
	private int totalValue;
	private int totalFlights;
	
	private Vector<Reservation> passengerReservations;
	
	public Passenger(){
		this.passengerReservations = new Vector<Reservation>();
	}
	
	public Passenger(String email, String fullName, String telephone) {
		this.email = email;
		this.fullName = fullName;
		this.telephone = telephone;
		
		passengerReservations = new Vector<Reservation>();
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public int getTotalFlightsOfPassenger() {
		return totalFlightsOfPassenger;
	}

	public void setTotalFlightsOfPassenger(int totalFlightsOfPassenger) {
		this.totalFlightsOfPassenger = totalFlightsOfPassenger;
	}
	
	public Vector<Reservation> getPassengerReservations() {
		return passengerReservations;
	}

	public void setPassengerReservations(Vector<Reservation> passengerReservations) {
		this.passengerReservations = passengerReservations;
	}
	
	public void addPassengerReservation(Reservation r) {
		passengerReservations.add(r);
	}
	
	public int getTotalValue() {
		return totalValue;
	}

	public void setTotalValue(int totalValue) {
		this.totalValue = totalValue;
	}

	public int getTotalFlights() {
		return totalFlights;
	}

	public void setTotalFlights(int totalFlights) {
		this.totalFlights = totalFlights;
	}
	
	public void print() {
	      
	    System.out.print("Email: " + email);
	    System.out.print("Fullname: " + fullName);
	    System.out.print("Telephone: " + telephone);
	}
 
	public void println() {
	      
	    System.out.println("Email: " + email);
	    System.out.println("Fullname: " + fullName);
	    System.out.println("Telephone: " + telephone);
	}
	
	//epistrefoun stoixeia tou epivati
	
	public String getPassengerInfo(){
		return this.fullName;
	}
	
	public int getPassengerInfo2(){
		return this.totalFlightsOfPassenger;
	}
}
